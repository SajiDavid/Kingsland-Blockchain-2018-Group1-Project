﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Nethereum.HdWallet;
using Nethereum.Web3;
using Nethereum.Web3.Accounts;
using Newtonsoft.Json;
using NBitcoin;
using Rijndael256;

public partial class RecoverWallet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnReturn_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }
    protected bool validateWords()
    {
        tbWords.Text = tbWords.Text.Trim();
        bool res = (tbWords.Text.Length > 0);
        if (res)
        {
            lbWords.ForeColor = new System.Drawing.Color();
        }
        else
        {
            lbWords.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbWords);
        }
        return (res);
    }
    protected bool validatePassword()
    {
        bool res = (tbPassword.Text.Length > 0);
        if (res)
        {
            lbPassword.ForeColor = new System.Drawing.Color();
        }
        else
        {
            lbPassword.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPassword);
        }
        return (res);
    }
    protected bool validateWalletFile()
    {
        bool res = (tbWalletFile.Text.Length > 0);
        if (res)
        {
            lbWalletFile.ForeColor = new System.Drawing.Color();
        }
        else
        {
            lbWalletFile.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbWalletFile);
        }
        return (res);
    }
    protected void btnRecover_Click(object sender, EventArgs e)
    {
        if (!validateWords() || !validatePassword() || !validateWalletFile())
            return;
        try
        {
            WalletClass.globalWallet = WalletClass.RecoverFromMnemonicPhraseAndSaveToJson(tbWords.Text, tbPassword.Text, tbWalletFile.Text);
            WalletClass.showAddresses(WalletClass.globalWallet, tbAddresses);
            WalletClass.showPrivKeys(WalletClass.globalWallet, tbPrivKeys);
        }
        catch (Exception ex)
        {
            tbAddresses.ForeColor = System.Drawing.Color.Red;
            tbAddresses.Text = ex.ToString();
        }
    }
}