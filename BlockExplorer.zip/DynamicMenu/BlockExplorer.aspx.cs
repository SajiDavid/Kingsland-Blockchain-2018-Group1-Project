﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class DynamicMenu : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable dt = this.BindMenuData(0);
            DynamicMenuControlPopulation(dt, 0, null);
        }
    }
    /// <summary>
    /// This function retur a datatable according to parent menu id passed by user
    /// </summary>
    /// <param name="parentmenuId">parent menu ID</param>
    /// <returns>data table</returns>
    protected DataTable BindMenuData(int parentmenuId)
    {
        //declaration of variable used
        DataSet ds = new DataSet();
        DataTable dt;
        DataRow dr;
        DataColumn menu;
        DataColumn pMenu;
        DataColumn title;
        DataColumn description;
        DataColumn URL;

        //create an object of datatable
        dt=new DataTable();

        //creating column of datatable with datatype
        menu= new DataColumn("MenuId",Type.GetType("System.Int32"));
        pMenu=new DataColumn("ParentId", Type.GetType("System.Int32"));
        title=new DataColumn("Title",Type.GetType("System.String"));
        description=new DataColumn("Description",Type.GetType("System.String"));
        URL=new DataColumn("URL",Type.GetType("System.String"));

        //bind data table columns in datatable
        dt.Columns.Add(menu);//1st column
        dt.Columns.Add(pMenu);//2nd column
        dt.Columns.Add(title);//3rd column
        dt.Columns.Add(description);//4th column
        dt.Columns.Add(URL);//5th column
       
        //creating data row and assiging the value to columns of datatable
        //1st row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 1;
        dr["ParentId"] = 0;
        dr["Title"] = "Chain";
        dr["Description"] = "Chain Operations";
        dr["URL"] = "";
        dt.Rows.Add(dr);

        //2nd row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 2;
        dr["ParentId"] = 0;
        dr["Title"] = "Blocks";
        dr["Description"] = "View Blocks";
        dr["URL"] = "~/Blocks.aspx";
        dt.Rows.Add(dr);

        //3rd row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 3;
        dr["ParentId"] = 0;
        dr["Title"] = "Transactions";
        dr["Description"] = "Transaction Operations";
        dr["URL"] = "";
        dt.Rows.Add(dr);

        //4th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 4;
        dr["ParentId"] = 0;
        dr["Title"] = "Accounts and Balances";
        dr["Description"] = "Check Balances of Accounts";
        dr["URL"] = "";
        dt.Rows.Add(dr);

        //5th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 5;
        dr["ParentId"] = 0;
        dr["Title"] = "Peers";
        dr["Description"] = "Peers Operations";
        dr["URL"] = "";
        dt.Rows.Add(dr);

        //6th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 6;
        dr["ParentId"] = 0;
        dr["Title"] = "Mining";
        dr["Description"] = "Mining Operation";
        dr["URL"] = "~/Mining.aspx";
        dt.Rows.Add(dr);

        //7th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 7;
        dr["ParentId"] = 1;
        dr["Title"] = "Info";
        dr["Description"] = "The Info of the Chain";
        dr["URL"] = "~/ChainInfo.aspx";
        dt.Rows.Add(dr);

        //8th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 8;
        dr["ParentId"] = 1;
        dr["Title"] = "Reset Chain";
        dr["Description"] = "Reset the entire Block Chain";
        dr["URL"] = "~/ResetChain.aspx";
        dt.Rows.Add(dr);

        //9th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 9;
        dr["ParentId"] = 3;
        dr["Title"] = "View Confirmed Transactions";
        dr["Description"] = "View confirmed transactions";
        dr["URL"] = "~/ConfirmedTransactions.aspx";
        dt.Rows.Add(dr);

        //10th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 10;
        dr["ParentId"] = 3;
        dr["Title"] = "View Pending Transactions";
        dr["Description"] = "View pending transactions";
        dr["URL"] = "~/PendingTransactions.aspx";
        dt.Rows.Add(dr);

        //11th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 11;
        dr["ParentId"] = 3;
        dr["Title"] = "View Individual Transaction";
        dr["Description"] = "View an individual transaction based on TransHash";
        dr["URL"] = "~/IndividualTransaction.aspx";
        dt.Rows.Add(dr);

        //12th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 12;
        dr["ParentId"] = 3;
        dr["Title"] = "List Transactions by Address";
        dr["Description"] = "List transactions of an address";
        dr["URL"] = "~/ListTransactions.aspx";
        dt.Rows.Add(dr);

        //13th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 13;
        dr["ParentId"] = 3;
        dr["Title"] = "Send Transaction";
        dr["Description"] = "Send a transaction";
        dr["URL"] = "~/SendTransaction.aspx";
        dt.Rows.Add(dr);

        //14th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 14;
        dr["ParentId"] = 4;
        dr["Title"] = "List All Accounts' Balances";
        dr["Description"] = "List balances of all accounts";
        dr["URL"] = "~/ListAllBalances.aspx";
        dt.Rows.Add(dr);

        //15th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 15;
        dr["ParentId"] = 4;
        dr["Title"] = "List Individual Account Balance";
        dr["Description"] = "List the balance of an individual account";
        dr["URL"] = "~/ListIndividualBalance.aspx";
        dt.Rows.Add(dr);

        //16th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 16;
        dr["ParentId"] = 5;
        dr["Title"] = "Connect to Node";
        dr["Description"] = "Connect from a node to another node";
        dr["URL"] = "~/ConnectNode.aspx";
        dt.Rows.Add(dr);

        //17th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 17;
        dr["ParentId"] = 5;
        dr["Title"] = "Display Peers";
        dr["Description"] = "Display all neighbouring peers of a node";
        dr["URL"] = "~/DisplayPeers.aspx";
        dt.Rows.Add(dr);

        //18th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 18;
        dr["ParentId"] = 0;
        dr["Title"] = "Wallet";
        dr["Description"] = "Wallet Operations";
        dr["URL"] = "";
        dt.Rows.Add(dr);

        //19th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 19;
        dr["ParentId"] = 18;
        dr["Title"] = "Create New Wallet";
        dr["Description"] = "Create a new wallet and save it to json file";
        dr["URL"] = "~/CreateWallet.aspx";
        dt.Rows.Add(dr);

        //20th row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 20;
        dr["ParentId"] = 18;
        dr["Title"] = "Load Existing Wallet";
        dr["Description"] = "Load an existing wallet from json file";
        dr["URL"] = "~/LoadWallet.aspx";
        dt.Rows.Add(dr);

        //21st row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 21;
        dr["ParentId"] = 18;
        dr["Title"] = "Recover Existing Wallet";
        dr["Description"] = "Recover an existing wallet from mnemonic phrases and save it to new json file";
        dr["URL"] = "~/RecoverWallet.aspx";
        dt.Rows.Add(dr);

        //22nd row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 22;
        dr["ParentId"] = 18;
        dr["Title"] = "Faucet Transaction";
        dr["Description"] = "Send a Faucet transaction from this wallet";
        dr["URL"] = "~/FaucetTransaction.aspx";
        dt.Rows.Add(dr);

        //23rd row of data table
        dr = dt.NewRow();
        dr["MenuId"] = 23;
        dr["ParentId"] = 18;
        dr["Title"] = "Check Balance";
        dr["Description"] = "Check overall balance from this wallet";
        dr["URL"] = "~/CheckWalletBalance.aspx";
        dt.Rows.Add(dr);

        ds.Tables.Add(dt);
        var dv = ds.Tables[0].DefaultView;
        dv.RowFilter = "ParentId='" + parentmenuId + "'";
        DataSet ds1 = new DataSet();
        var newdt = dv.ToTable();
        return newdt;
    }

    /// <summary>
    /// This is a recursive function to fetchout the data to create a menu from data table
    /// </summary>
    /// <param name="dt">datatable</param>
    /// <param name="parentMenuId">parent menu Id of integer type</param>
    /// <param name="parentMenuItem"> Menu Item control</param>
    protected void DynamicMenuControlPopulation(DataTable dt, int parentMenuId, MenuItem parentMenuItem)
    {
        string currentPage = Path.GetFileName(Request.Url.AbsolutePath);
        foreach (DataRow row in dt.Rows)
        {
            MenuItem menuItem = new MenuItem
            {
                Value = row["MenuId"].ToString(),
                Text = row["Title"].ToString(),
                NavigateUrl = row["URL"].ToString(),
                Selected = row["URL"].ToString().EndsWith(currentPage, StringComparison.CurrentCultureIgnoreCase)
            };
            if (parentMenuId == 0)
            {
                Menu1.Items.Add(menuItem);
                DataTable dtChild = this.BindMenuData(int.Parse(menuItem.Value));
                DynamicMenuControlPopulation(dtChild, int.Parse(menuItem.Value), menuItem);
            }
            else
            {
                    parentMenuItem.ChildItems.Add(menuItem);
                    DataTable dtChild = this.BindMenuData(int.Parse(menuItem.Value));
                    DynamicMenuControlPopulation(dtChild, int.Parse(menuItem.Value), menuItem);
            }
        }
    }

    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {

    }
}