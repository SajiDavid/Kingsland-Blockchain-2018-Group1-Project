﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using Nethereum.HdWallet;
using Nethereum.Web3;
using Nethereum.Web3.Accounts;
using Newtonsoft.Json;
using NBitcoin;
using Rijndael256;

public partial class CreateWallet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected bool verifyPassword()
    {
        if( tbEnterPassword.Text.Length == 0 )
        {
            lbEnterPassword.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbEnterPassword);
            return (false);
        }
        else
        {
            lbEnterPassword.ForeColor = new System.Drawing.Color();
        }
        if (tbConfirmPassword.Text.Length == 0)
        {
            lbConfirmPassword.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbConfirmPassword);
            return (false);
        }
        else
        {
            lbConfirmPassword.ForeColor = new System.Drawing.Color();
        }
        bool res = (tbEnterPassword.Text == tbConfirmPassword.Text);
        lbPasswordMatch.Visible = !res;
        if( !res )
        {
            tbEnterPassword.Text = "";
            tbConfirmPassword.Text = "";
            this.Page.SetFocus(tbEnterPassword);
        }
        return (res);
    }
    protected bool verifyFolder()
    {
        bool res = Directory.Exists(tbWalletFolder.Text);
        if( res )
        {
            lbSaveWallet.ForeColor = new System.Drawing.Color();
        }
        else
        {
            lbSaveWallet.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbWalletFolder);
        }
        return (res);
    }
    protected void btnCreateWallet_Click(object sender, EventArgs e)
    {
        string wallet_file = "";
        if (!verifyPassword() || !verifyFolder())
            return;
        try
        {
            WalletClass.globalWallet = WalletClass.CreateWallet(tbConfirmPassword.Text, tbWalletFolder.Text, out wallet_file );
            lbResult.Text = "Create Wallet at " + wallet_file + "!";
            lbResult.ForeColor = System.Drawing.Color.Green;
            WalletClass.showAddresses(WalletClass.globalWallet, tbAddresses);
            WalletClass.showPrivKeys(WalletClass.globalWallet, tbPrivKeys);
            WalletClass.showWords(WalletClass.globalWallet, tbWords);
        }
        catch( Exception ex )
        {
            lbResult.Text = ex.ToString();
            lbResult.ForeColor = System.Drawing.Color.Red;
        }
    }

    protected void btnReturn_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }

    protected void tbAddresses_TextChanged(object sender, EventArgs e)
    {

    }
}