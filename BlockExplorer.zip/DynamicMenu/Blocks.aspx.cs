﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;

public partial class Blocks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
    }

    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rblBlockMode.SelectedItem.Text == "All blocks")
        {
            tbxBlockIndex.Enabled = false;
        }
        else
        {
            tbxBlockIndex.Enabled = true;
        }
    }

    protected bool ValidateIPAddr()
    {
        tbxIPAddr.Text = tbxIPAddr.Text.Trim();
        if (tbxIPAddr.Text.Length == 0)
        {
            lbIPAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbxIPAddr);
            return (false);
        }
        else
        {
            lbIPAddrTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
    }
    protected bool ValidatePort()
    {
        bool bPortValid;
        int iPort;
        tbPort.Text = tbPort.Text.Trim();
        bPortValid = int.TryParse(tbPort.Text, out iPort);
        if(bPortValid)
        {
            lbPort.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbPort.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPort);
            return (false);
        }
    }
    protected bool ValidateBlockIndex()
    {
        bool bBlockIndexValid;
        int iBlockIndex;
        if (rblBlockMode.SelectedItem.Text == "All blocks")
        {
            lbBlockTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            tbxBlockIndex.Text = tbxBlockIndex.Text.Trim();
            bBlockIndexValid = int.TryParse(tbxBlockIndex.Text, out iBlockIndex);
            if((bBlockIndexValid) && (iBlockIndex>=0))
            {
                lbBlockTitle.ForeColor = new System.Drawing.Color();
                return (true);
            }
            else
            {
                lbBlockTitle.ForeColor = System.Drawing.Color.Red;
                this.Page.SetFocus(tbxBlockIndex);
                return (false);
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!ValidateIPAddr()||!ValidatePort()||!ValidateBlockIndex())
            return;
        string Url;
        MyWebRequest myRequest;
        string response = "";

        lbBlockContent.Enabled = false;
        tbxBlockContent.Enabled = false;
        if (rblBlockMode.SelectedItem.Text == "All blocks")
            Url = "http://" + tbxIPAddr.Text + ":" + tbPort.Text + "/blocks";
        else
            Url = "http://" + tbxIPAddr.Text + ":" + tbPort.Text + "/blocks/" + tbxBlockIndex.Text.ToString();
        //create the constructor with post type and few data
        myRequest = new MyWebRequest(Url, "GET");
        //show the response string on the console screen.
        try
        {
            response = myRequest.GetResponse();
            tbxBlockContent.ForeColor = new System.Drawing.Color();
            tbxBlockContent.Text = response;
        }
        catch (WebException we)
        {
            tbxBlockContent.ForeColor = System.Drawing.Color.Red;
            if (we.Message.Contains("(408)"))
                tbxBlockContent.Text = "Error: Block Index " + tbxBlockIndex.Text.ToString() + " out of range!";
            else
                tbxBlockContent.Text = we.Message;
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }

    protected void tbxBlockContent_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbxIPAddr_TextChanged(object sender, EventArgs e)
    {
    }

    protected void tbPort_TextChanged(object sender, EventArgs e)
    {
    }
}