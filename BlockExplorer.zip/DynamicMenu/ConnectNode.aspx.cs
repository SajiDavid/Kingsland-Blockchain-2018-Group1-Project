﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;

public partial class ConnectNode : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void tbxIPAddr_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbPort_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbxToIPAddr_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbxToPort_TextChanged(object sender, EventArgs e)
    {

    }
    protected bool ValidateFromIPAddr()
    {
        tbxFromIPAddr.Text = tbxFromIPAddr.Text.Trim();
        if (tbxFromIPAddr.Text.Length == 0)
        {
            lbFromIPAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbxFromIPAddr);
            return (false);
        }
        else
        {
            lbFromIPAddrTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
    }
    protected bool ValidateFromPort()
    {
        bool bPortValid;
        int iPort;
        tbFromPort.Text = tbFromPort.Text.Trim();
        bPortValid = int.TryParse(tbFromPort.Text, out iPort);
        if (bPortValid)
        {
            lbFromPort.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbFromPort.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbFromPort);
            return (false);
        }
    }
    protected bool ValidateToIPAddr()
    {
        tbxToIPAddr.Text = tbxToIPAddr.Text.Trim();
        if (tbxToIPAddr.Text.Length == 0)
        {
            lbToIPAddr.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbxToIPAddr);
            return (false);
        }
        else
        {
            lbToIPAddr.ForeColor = new System.Drawing.Color();
            return (true);
        }
    }
    protected bool ValidateToPort()
    {
        bool bPortValid;
        int iPort;
        tbxToPort.Text = tbxToPort.Text.Trim();
        bPortValid = int.TryParse(tbxToPort.Text, out iPort);
        if (bPortValid)
        {
            lbToPort.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbToPort.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbxToPort);
            return (false);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!ValidateFromIPAddr() || !ValidateFromPort() || !ValidateToIPAddr() || !ValidateToPort())
            return;
        if (tbxFromIPAddr.Text == tbxToIPAddr.Text && tbFromPort.Text == tbxToPort.Text)
        {
            lbSameNodeError.Visible = true;
            return;
        }
        else
            lbSameNodeError.Visible = false;
        string Url = "http://" + tbxFromIPAddr.Text + ":" + tbFromPort.Text + "/peers/connect";
        string data = "{ \"peerUrl\": \"" + tbxToIPAddr.Text + ":" + tbxToPort.Text + "\" }";
        string response = "";
        string status_code = "";
        //show the response string on the console screen.
        if(MyWebRequest.PostData(Url, data, out response, out status_code))
        {
            tbxConnectNodeMsg.ForeColor = new System.Drawing.Color();
            tbxConnectNodeMsg.Text = response;
        }
        else
        {
            tbxConnectNodeMsg.ForeColor = System.Drawing.Color.Red;
            tbxConnectNodeMsg.Text = response;
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }

    protected void tbxBlockContent_TextChanged(object sender, EventArgs e)
    {

    }
}