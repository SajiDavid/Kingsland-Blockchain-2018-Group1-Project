﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;

public partial class CheckWalletBalance : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (WalletClass.globalWallet != null)
        {
            lbWalletUnloaded.Text = "Wallet Loaded";
            lbWalletUnloaded.ForeColor = System.Drawing.Color.Green;
            tbxIPAddr.Enabled = true;
            tbPort.Enabled = true;
            btnViewBalance.Enabled = true;
        }
        else
        {
            lbWalletUnloaded.Text = "Wallet NOT Loaded";
            lbWalletUnloaded.ForeColor = System.Drawing.Color.Red;
            tbxIPAddr.Enabled = false;
            tbPort.Enabled = false;
            btnViewBalance.Enabled = false;
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }
    protected bool ValidateIPAddr()
    {
        tbxIPAddr.Text = tbxIPAddr.Text.Trim();
        if (tbxIPAddr.Text.Length == 0)
        {
            lbIPAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbxIPAddr);
            return (false);
        }
        else
        {
            lbIPAddrTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
    }
    protected bool ValidatePort()
    {
        bool bPortValid;
        int iPort;
        tbPort.Text = tbPort.Text.Trim();
        bPortValid = int.TryParse(tbPort.Text, out iPort);
        if (bPortValid)
        {
            lbPort.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbPort.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPort);
            return (false);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!ValidateIPAddr() || !ValidatePort())
            return;
        string url_header = "http://" + tbxIPAddr.Text + ":" + tbPort.Text + "/address/";
        // public static int[] computeWalletBalance(string url_header, Wallet wallet, out int sum)
        try
        {
            int sum = 0;
            AddressBalance[] addr_balances = new AddressBalance[20];
            addr_balances = WalletClass.computeWalletBalance(url_header, WalletClass.globalWallet, out sum);
            tbxBalanceInfo.ForeColor = new System.Drawing.Color();
            tbxBalanceInfo.Text = "    Address                                        Balance" + "\n";
            tbxBalanceInfo.Text += "----------------------------------------------------------------" + "\n";
            for ( int i = 0; i < 20; i++ )
            {
                tbxBalanceInfo.Text += addr_balances[i].address + "           " + addr_balances[i].value.ToString() + "\n";
            }
            tbxBalanceInfo.Text += "================================================================" + "\n";
            tbxBalanceInfo.Text += "    Total                                          " + sum.ToString() + "\n";
        }
        catch (WebException we)
        {
            tbxBalanceInfo.ForeColor = System.Drawing.Color.Red;
            tbxBalanceInfo.Text = we.Message;
        }
    }

    protected void tbxIPAddr_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbPort_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbxBlockContent_TextChanged(object sender, EventArgs e)
    {

    }
}