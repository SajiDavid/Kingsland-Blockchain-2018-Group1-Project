﻿using System;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;
using static System.Console;
using System.Collections;
using System.IO;
using System.Threading.Tasks;
using Nethereum.HdWallet;
using Nethereum.Web3;
using Nethereum.Web3.Accounts;
using Newtonsoft.Json;
using NBitcoin;
using Rijndael256;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;

/// <summary>
/// Summary description for WalletClass
/// </summary>
public struct AddressBalance
{
    public string address;
    public int value;
    public AddressBalance(string addr, int val)
    {
        this.address = addr;
        this.value = val;
    }
}
public class WalletClass
{
    const string network = "ropsten"; // TODO: Specify wich network you are going to use.
    const string workingDirectory = @"Wallets\"; // Path where you want to store the Wallets
    public static Wallet globalWallet = null;   // global Wallet for sending transactions and minings
    public static bool getMiningJob_succ;
    public static string FaucetAccount = "c3293572dbe6ebc60de4a20ed0e21446cae66b17";
    public static string FaucetPubKey = "c74a8458cd7a7e48f4b7ae6f4ae9f56c5c88c0f03e7c59cb4132b9d9d1600bba1";
    public static string FaucetPrvKey = "7e4670ae70c98d24f3662c172dc510a085578b9ccc717e6c2f4e547edd960a34";
    public WalletClass()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public static Wallet CreateWallet(string password, string pathfile, out string wallet_file )
    {
        Wallet wallet = new Wallet(Wordlist.English, WordCount.Twelve); // Create brand-new wallet
        string words = string.Join(" ", wallet.Words);
        string fileName = string.Empty;
        wallet_file = string.Empty;
        try
        {
            fileName = SaveWalletToJsonFile(wallet, password, pathfile);
        }
        catch (Exception e)
        {
            WriteLine($"ERROR! The file {fileName} can`t be saved! {e}");
            throw e;
        }

        WriteLine("New Wallet was created successfully!");
        WriteLine("Write down the following mnemonic words and keep them in the save place.");
        // TODO: Display the Words here.
        WriteLine(words);
        WriteLine("Seed: ");
        // TODO: Display the Seed here.
        WriteLine(wallet.Seed);
        WriteLine();
        // TODO: Implement and use PrintAddressesAndKeys to print all the Addresses and Keys.
        PrintAddressesAndKeys(wallet);
        if (pathfile[pathfile.Length - 1] != '\\')
            wallet_file = pathfile + "\\" + fileName;
        else
            wallet_file = pathfile + fileName;
        return wallet;
    }
    private static void PrintAddressesAndKeys(Wallet wallet)
    {
        // TODO: Print all the Addresses and the coresponding Private Keys.
        WriteLine("Addresses:");
        for (int i = 0; i < 20; i++)
        {
            WriteLine(wallet.GetAccount(i).Address);
        }

        WriteLine();
        WriteLine("Private Keys:");
        for (int i = 0; i < 20; i++)
        {
            WriteLine(wallet.GetAccount(i).PrivateKey);
        }
        WriteLine();
    }
    public static AddressBalance[] computeWalletBalance(string url_header, Wallet wallet, out int sum)
    {
        AddressBalance[] addr_balances = new AddressBalance[20];
        string address;
        int value;
        sum = 0;

        try
        {
            for (int i = 0; i < 20; i++)
            {
                address = wallet.GetAccount(i).Address.Remove(0, 2);
                value = checkSafeBalance(url_header, address);
                addr_balances[i] = new AddressBalance(address, value);
                sum += value;
            }
            return (addr_balances);
        }
        catch (WebException we)
        {
            throw we;
        }
    }
    public static int checkSafeBalance(string url_header, string addr)
    {
        MyWebRequest myRequest;
        String response = "";
        String Url = url_header + addr + "/balance";
        //create the constructor with post type and few data
        myRequest = new MyWebRequest(Url, "GET");
        //show the response string on the console screen.
        try
        {
            response = myRequest.GetResponse();
            JObject jObject = JObject.Parse(response);
            string sValue = (string)jObject.SelectToken("safeBalance");
            int iValue = Convert.ToInt32(sValue);
            return (iValue);
        }
        catch (WebException we)
        {
            throw we;
        }
    }
    private static string SaveWalletToJsonFile(Wallet wallet, string password, string pathfile)
    {
        //TODO: Encrypt and Save the Wallet to JSON.
        string words = string.Join(" ", wallet.Words);
        var encryptedWords = Rijndael.Encrypt(words, password, KeySize.Aes256); // Encrypt the Mnemonic phrase
        string date = DateTime.Now.ToString();
        // Anonymous object containing encrypted Words and date will be written in the Json file
        var walletJsonData = new { encryptedWords = encryptedWords, date = date };
        string json = JsonConvert.SerializeObject(walletJsonData);
        Random random = new Random();
        var fileName =
            "EthereumWallet "
            + DateTime.Now.Year + "-"
            + DateTime.Now.Month + "-"
            + DateTime.Now.Day + "_"
            + DateTime.Now.Hour + "_"
            + DateTime.Now.Minute + "_"
            + DateTime.Now.Second + "_"
            + random.Next(0, 10000) + ".json";
        File.WriteAllText(Path.Combine(pathfile, fileName), json);
        WriteLine($"Wallet saved in file: {fileName}");
        return fileName;
    }
    public static Wallet LoadWalletFromJsonFile(string pathToFile, string pass)
    {
        //TODO: Implement the logic that is needed to Load and Wallet from JSON.
        string words = string.Empty;
        // Read from fileName
        WriteLine($"Read from {pathToFile}");
        try
        {
            string line = File.ReadAllText(pathToFile);
            dynamic results = JsonConvert.DeserializeObject<dynamic>(line);
            string encryptedWords = results.encryptedWords;
            words = Rijndael.Decrypt(encryptedWords, pass, KeySize.Aes256);
            string dateAndTime = results.date;
        }
        catch (Exception e)
        {
            WriteLine("ERROR!" + e);
        }
        return Recover(words);
    }
    private static Wallet Recover(string words)
    {
        // TODO: Recover a Wallet from existing mnemonic phrase (words).
        Wallet wallet = new Wallet(words, null);
        WriteLine("Wallet was successfully recovered.");
        WriteLine("Words: " + string.Join(" ", wallet.Words));
        WriteLine("Seed: " + string.Join(" ", wallet.Seed));
        WriteLine();
        PrintAddressesAndKeys(wallet);
        return wallet;
    }
    public static void showAddresses(Wallet wallet, System.Web.UI.WebControls.TextBox tb)
    {
        string addresses = "";
        for (int i = 0; i < 20; i++)
            addresses += wallet.GetAccount(i).Address + "\n";
        tb.ForeColor = new System.Drawing.Color();
        tb.Text = addresses;
    }
    public static void showPrivKeys(Wallet wallet, System.Web.UI.WebControls.TextBox tb)
    {
        string private_keys = "";
        for (int i = 0; i < 20; i++)
            private_keys += wallet.GetAccount(i).PrivateKey + "\n";
        tb.ForeColor = new System.Drawing.Color();
        tb.Text = private_keys;
    }
    public static void showWords(Wallet wallet, System.Web.UI.WebControls.TextBox tb)
    {
        string words = string.Join("\n", wallet.Words);
        tb.ForeColor = new System.Drawing.Color();
        tb.Text = words;
    }
    public static Wallet RecoverFromMnemonicPhraseAndSaveToJson(string words, string password, string pathfile)
    {
        // TODO: Recover from Mnemonic phrases and Save to JSON.
        Wallet wallet = Recover(words);
        string fileName = string.Empty;
        try
        {
            fileName = SaveWalletToJsonFile(wallet, password, pathfile);
        }
        catch (Exception)
        {
            WriteLine($"ERROR! The file {fileName} with recovered wallet can't be saved!");
            throw;
        }
        return wallet;
    }
    public static void Receive(Wallet wallet)
    {
        // TODO: Print all avaiable addresses in Wallet.
        if (wallet.GetAddresses().Count() > 0)
        {
            for (int i = 0; i < 20; i++)
            {
                WriteLine(wallet.GetAccount(i).Address);
            }
            WriteLine();
        }
        else
        {
            WriteLine("No addresses founded!");
        }
    }
    public static bool isAddrInWallet(Wallet wallet, string fromAddress)
    {
        try
        {
            Account accountFrom = wallet.GetAccount(fromAddress);
            string privateKeyFrom = accountFrom.PrivateKey;
            return (privateKeyFrom != string.Empty);
        }
        catch( Exception ex )
        {
            WriteLine(ex.ToString());
            return (false);
        }
    }
    public static bool getAddrFromWallet(Wallet wallet, string privKey, out string addr)
    {
        addr = "";
        try
        {
            for (int i = 0; i < 20; i++)
            {
                if (wallet.GetAccount(i).PrivateKey.Contains(privKey))
                {
                    addr = wallet.GetAccount(i).Address;
                    if (addr.StartsWith("0x"))
                        addr = addr.Remove(0, 2);
                    return (true);
                }
            }
            return (false);
        }
        catch (Exception ex)
        {
            WriteLine(ex.ToString());
            return (false);
        }
    }
    public static bool getPrivKeyFromWallet(Wallet wallet, string addr, out string privKey)
    {
        privKey = "";
        try
        {
            for (int i = 0; i < 20; i++)
            {
                if (wallet.GetAccount(i).Address.Contains(addr))
                {
                    privKey = wallet.GetAccount(i).PrivateKey;
                    if (privKey.StartsWith("0x"))
                    {
                        privKey = privKey.Remove(0, 2);
                        if(privKey.StartsWith("00") )
                            privKey = privKey.Remove(0, 2);
                    }
                    return (true);
                }
            }
            return (false);
        }
        catch (Exception ex)
        {
            WriteLine(ex.ToString());
            return (false);
        }
    }
    private static async Task Send(Wallet wallet, string fromAddress, string toAddress, double amountOfCoins)
    {
        // TODO: Generate and Send a transaction.
        Account accountFrom = wallet.GetAccount(fromAddress);
        string privateKeyFrom = accountFrom.PrivateKey;
        if (privateKeyFrom == string.Empty)
        {
            WriteLine("Address sending coins is not from current wallet!");
            throw new Exception("Address sending coins is not from current wallet!");
        }

        var web3 = new Web3(accountFrom, network);
        var wei = Web3.Convert.ToWei(amountOfCoins);
        try
        {
            var transaction =
                await web3.TransactionManager.SendTransactionAsync(
                    accountFrom.Address,
                    toAddress,
                    new Nethereum.Hex.HexTypes.HexBigInteger(wei));
            WriteLine("Transaction has been sent successfully!");
        }
        catch (Exception e)
        {
            WriteLine($"ERROR! The transaction can't be completed! {e}");
            throw e;
        }
    }
    private static async Task Balance(Web3 web3, Wallet wallet)
    {
        // TODO: Print all addresses and their balance. Print the Total Balance of the Wallet as well.
        decimal totalBalance = 0.0m;
        for (int i = 0; i < 20; i++)
        {
            var balance = await web3.Eth.GetBalance.SendRequestAsync(wallet.GetAccount(i).Address);
            var etherAmount = Web3.Convert.FromWei(balance.Value);
            totalBalance += etherAmount;
            WriteLine(wallet.GetAccount(i).Address + " " + etherAmount + " ETH");
        }
        WriteLine($"Total balance: {totalBalance} ETH \n");
    }
}