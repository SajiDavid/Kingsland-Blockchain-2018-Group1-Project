﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Security.Cryptography;
using Org.BouncyCastle.Math.EC;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Asn1.X9;
using Org.BouncyCastle.Asn1.Sec;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Signers;
using Newtonsoft.Json;

/// <summary>
/// Summary description for Class1
/// </summary>
public static class CryptoClass
{
    public static string BlockDataHash;
    static readonly X9ECParameters curve = SecNamedCurves.GetByName("secp256k1");
    private static readonly ECDomainParameters Domain = new ECDomainParameters(curve.Curve, curve.G, curve.N, curve.H);
    public static string BytesToHex(byte[] bytes)
    {
        return (string.Concat(bytes.Select(b => b.ToString("x2"))));
    }
    public static byte[] GetBytes(string data)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(data);
        return (bytes);
    }
    public static string CalcRipeMD160(string text)
    {
        byte[] bytes = GetBytes(text);
        RipeMD160Digest digest = new RipeMD160Digest();
        digest.BlockUpdate(bytes, 0, bytes.Length);
        byte[] result = new byte[digest.GetDigestSize()];
        digest.DoFinal(result, 0);
        return (BytesToHex(result));
    }
    public static byte[] CalcSHA256(string text)
    {
        byte[] bytes = GetBytes(text);
        Sha256Digest digest = new Sha256Digest();
        digest.BlockUpdate(bytes, 0, bytes.Length);
        byte[] result = new byte[digest.GetDigestSize()];
        digest.DoFinal(result, 0);
        return (result);
    }
    public static string ComputeSha256Hash(string rawData)
    {
        // Create a SHA256   
        using (SHA256 sha256Hash = SHA256.Create())
        {
            // ComputeHash - returns byte array  
            byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

            // Convert byte array to a string   
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                builder.Append(bytes[i].ToString("x2"));
            }
            return builder.ToString();
        }
    }
    public static AsymmetricCipherKeyPair GenerateRandomKeys(int keySize = 256)
    {
        ECKeyPairGenerator gen = new ECKeyPairGenerator();
        SecureRandom secureRandom = new SecureRandom();
        KeyGenerationParameters keyGenParam = new KeyGenerationParameters(secureRandom, keySize);
        gen.Init(keyGenParam);
        return (gen.GenerateKeyPair());
    }
    public static string EncodeECPointHexCompressed(Org.BouncyCastle.Math.EC.ECPoint point)
    {
        Org.BouncyCastle.Math.BigInteger x = point.XCoord.ToBigInteger();
        Org.BouncyCastle.Math.BigInteger y = point.YCoord.ToBigInteger();

        return (x.ToString(16) + Convert.ToInt32(y.TestBit(0)));
    }
    private static void RandomPrivateKeyToAddress()
    {
        Console.WriteLine("Random private key --> public key --> address");
        Console.WriteLine("---------------------------------------------");

        var keyPair = GenerateRandomKeys();

        Org.BouncyCastle.Math.BigInteger privateKey = new Org.BouncyCastle.Math.BigInteger(((ECPrivateKeyParameters)keyPair.Private).D.ToByteArray());
        Console.WriteLine("Private key (hex): " + privateKey.ToString(16));
        Console.WriteLine("Private key: " + privateKey.ToString());

        Org.BouncyCastle.Math.EC.ECPoint pubKey = ((ECPublicKeyParameters)keyPair.Public).Q;
        Console.WriteLine("Public key: ({0}, {1})",
            pubKey.XCoord.ToBigInteger().ToString(10),
            pubKey.YCoord.ToBigInteger().ToString(10));

        string pubKeyCompressed = EncodeECPointHexCompressed(pubKey);
        Console.WriteLine("Public key (compressed): " + pubKeyCompressed);

        string addr = CalcRipeMD160(pubKeyCompressed);
        Console.WriteLine("Blockchain address: " + addr);
    }
    public static Org.BouncyCastle.Math.EC.ECPoint GetPublicKeyFromPrivateKey(Org.BouncyCastle.Math.BigInteger privKey)
    {
        Org.BouncyCastle.Math.EC.ECPoint pubKey = curve.G.Multiply(privKey).Normalize();
        return (pubKey);
    }
    private static Org.BouncyCastle.Math.BigInteger[] SignData(Org.BouncyCastle.Math.BigInteger privateKey, byte[] data)
    {
        ECPrivateKeyParameters keyParameters = new ECPrivateKeyParameters(privateKey, Domain);
        IDsaKCalculator kCalculator = new HMacDsaKCalculator(new Sha256Digest());
        ECDsaSigner signer = new ECDsaSigner(kCalculator);
        signer.Init(true, keyParameters);
        Org.BouncyCastle.Math.BigInteger[] signature = signer.GenerateSignature(data);

        return (signature);
    }
    public static ECPublicKeyParameters ToPublicKey(string privateKey)
    {
        Org.BouncyCastle.Math.BigInteger d = new Org.BouncyCastle.Math.BigInteger(privateKey, 16);
        var q = Domain.G.Multiply(d);

        var publicParams = new ECPublicKeyParameters(q, Domain);

        return (publicParams);
    }
    public static bool VerifySignature(ECPublicKeyParameters pubKey, Org.BouncyCastle.Math.BigInteger[] signature, byte[] msg)
    {
        IDsaKCalculator kCalculator = new HMacDsaKCalculator(new Sha256Digest());
        ECDsaSigner signer = new ECDsaSigner(kCalculator);
        signer.Init(false, pubKey);

        return signer.VerifySignature(msg, signature[0], signature[1]);
    }
    public static string PrivKey2PubKeyAndAddr(string senderPrivKeyHex, out string senderAddress)
    {
        Org.BouncyCastle.Math.BigInteger privateKey = new Org.BouncyCastle.Math.BigInteger(senderPrivKeyHex, 16);
        Org.BouncyCastle.Math.EC.ECPoint pubKey = GetPublicKeyFromPrivateKey(privateKey);
        string senderPubKeyCompressed = EncodeECPointHexCompressed(pubKey);
        senderAddress = CalcRipeMD160(senderPubKeyCompressed);
        return (senderPubKeyCompressed);
    }
    public static Org.BouncyCastle.Math.BigInteger[] signTrans(string privKeyHex, string fromAddr, string toAddr, string pubkey, int value, int fee, string data, string date_created )
    {
        Org.BouncyCastle.Math.BigInteger privateKey = new Org.BouncyCastle.Math.BigInteger(privKeyHex, 16);
        var tran = new
        {
            from = fromAddr,
            to = toAddr,
            senderPubKey = pubkey,
            value = value,
            fee = fee,
            data = data,
            dateCreated = date_created
        };
        string tranJson = JsonConvert.SerializeObject(tran);
        byte[] tranHash = CalcSHA256(tranJson);
        Org.BouncyCastle.Math.BigInteger[] tranSignature = SignData(privateKey, tranHash);
        return (tranSignature);
    }
    public static void SignAndVerifyTransaction(string recipientAddress, int value,
        int fee, string iso8601datetime, string senderPrivKeyHex)
    {
        Console.WriteLine("Generate and sign a transaction");
        Console.WriteLine("-------------------------------");

        Console.WriteLine("Sender private key: " + senderPrivKeyHex);
        Org.BouncyCastle.Math.BigInteger privateKey = new Org.BouncyCastle.Math.BigInteger(senderPrivKeyHex, 16);

        Org.BouncyCastle.Math.EC.ECPoint pubKey = GetPublicKeyFromPrivateKey(privateKey);
        string senderPubKeyCompressed = EncodeECPointHexCompressed(pubKey);
        Console.WriteLine("Public key (compressed): " + senderPubKeyCompressed);

        string senderAddress = CalcRipeMD160(senderPubKeyCompressed);
        Console.WriteLine("Blockchain address: " + senderAddress);

        var tran = new
        {
            from = senderAddress,
            to = recipientAddress,
            senderPubKey = senderPubKeyCompressed,
            value,
            fee,
            dateCreated = iso8601datetime
        };
        string tranJson = JsonConvert.SerializeObject(tran);
        Console.WriteLine("Transaction (JSON): {0}", tranJson);

        byte[] tranHash = CalcSHA256(tranJson);
        Console.WriteLine("Transaction hash(sha256): {0}", BytesToHex(tranHash));

        Org.BouncyCastle.Math.BigInteger[] tranSignature = SignData(privateKey, tranHash);
        Console.WriteLine("Transaction signature: [{0}, {1}]", tranSignature[0].ToString(16), tranSignature[1].ToString(16));

        var tranSigned = new
        {
            from = senderAddress,
            to = recipientAddress,
            senderPubKey = senderPubKeyCompressed,
            value,
            fee,
            dateCreated = iso8601datetime,
            senderSignature = new[]
            {
                tranSignature[0].ToString(16),
                tranSignature[1].ToString(16)
            }
        };

        string signedTranJson = JsonConvert.SerializeObject(tranSigned, Formatting.Indented);
        Console.WriteLine("Signed transaction (JSON):");
        Console.WriteLine(signedTranJson);

        ECPublicKeyParameters ecPubKey = ToPublicKey(senderPrivKeyHex);
        bool isVerified = VerifySignature(ecPubKey, tranSignature, tranHash);
        Console.WriteLine("Is the signature: valid ? - " + isVerified);
    }
}

