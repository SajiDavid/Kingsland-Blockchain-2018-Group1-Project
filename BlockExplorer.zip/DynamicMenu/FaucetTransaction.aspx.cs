﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Org.BouncyCastle.Math.EC;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Asn1.X9;
using Org.BouncyCastle.Asn1.Sec;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Signers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;

public partial class FaucetTransaction : System.Web.UI.Page
{
    bool firstRun;
    protected void Page_Load(object sender, EventArgs e)
    {
        firstRun = true;
        if (WalletClass.globalWallet != null)
        {
            lbWalletUnloaded.Text = "Wallet Loaded";
            lbWalletUnloaded.ForeColor = System.Drawing.Color.Green;
            tbxIPAddr.Enabled = true;
            tbPort.Enabled = true;
            btnSendTransaction.Enabled = true;
        }
        else
        {
            lbWalletUnloaded.Text = "Wallet NOT Loaded";
            lbWalletUnloaded.ForeColor = System.Drawing.Color.Red;
            tbxIPAddr.Enabled = false;
            tbPort.Enabled = false;
            btnSendTransaction.Enabled = false;
        }
    }
    protected bool ValidateIPAddr()
    {
        tbxIPAddr.Text = tbxIPAddr.Text.Trim();
        if (tbxIPAddr.Text.Length == 0)
        {
            lbIPAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbxIPAddr);
            return (false);
        }
        else
        {
            lbIPAddrTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
    }
    protected bool ValidatePort()
    {
        bool bPortValid;
        int iPort;
        tbPort.Text = tbPort.Text.Trim();
        bPortValid = int.TryParse(tbPort.Text, out iPort);
        if (bPortValid)
        {
            lbPort.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbPort.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPort);
            return (false);
        }
    }
    protected void setTransVisible(bool visible)
    {
        lbTransInfo.Visible = visible;
        lbSenderAddrTitle.Visible = visible;
        lbSenderAddrValue.Visible = visible;
        lbRecipientAddrTitle.Visible = visible;
        tbRecipientAddrValue.Visible = visible;
        lbValueTitle.Visible = visible;
        tbValue.Visible = visible;
        lbDataTitle.Visible = visible;
        tbDataValue.Visible = visible;
        lbDateCreatedTitle.Visible = visible;
        lbDateCreatedValue.Visible = visible;
        lbSignatureTitle.Visible = visible;
        lbSignatureValue.Visible = visible;
        btnSubmit.Visible = visible;
    }
    protected void setTransEnabled(bool enabled)
    {
        tbRecipientAddrValue.Enabled = enabled;
        tbValue.Enabled = enabled;
        tbDataValue.Enabled = enabled;
        btnSubmit.Enabled = enabled;
        if (enabled)
        {
            tbRecipientAddrValue.Text = "";
            tbValue.Text = "";
            tbDataValue.Text = "";
            lbDateCreatedValue.Text = "";
            lbSignatureValue.Text = "";
            lbReturnMessage.Text = "";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!ValidateIPAddr() || !ValidatePort())
            return;
        if (firstRun)
        {
            firstRun = false;
            setTransVisible(true);
        }
        setTransEnabled(true);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }
    protected bool validateRecAddr()
    {
        bool valid = true;
        tbRecipientAddrValue.Text = tbRecipientAddrValue.Text.Trim();
        string RecAddr = tbRecipientAddrValue.Text;
        if (RecAddr.Length != 40)
            valid = false;
        for (int c = 0; c < RecAddr.Length; c++)
        {
            if ((RecAddr[c] >= '0' && RecAddr[c] <= '9') || (RecAddr[c] >= 'a' && RecAddr[c] <= 'f') || (RecAddr[c] >= 'A' && RecAddr[c] <= 'F'))
                continue;
            else
                valid = false;
        }
        if (!valid)
        {
            lbRecipientAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbRecipientAddrValue);
        }
        else
        {
            lbRecipientAddrTitle.ForeColor = new System.Drawing.Color();
        }
        return (valid);
    }
    protected bool validateTransValue()
    {
        int iValue;
        bool bValidValue;
        bValidValue = int.TryParse(tbValue.Text, out iValue);
        if (bValidValue && iValue > 0)
        {
            lbValueTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbValueTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbValue);
            return (false);
        }
    }
    protected bool deriveRecipientPrivKey(string addr, out string privKey, out string pubKey)
    {
        privKey = "";
        pubKey = "";
        bool res = WalletClass.getPrivKeyFromWallet(WalletClass.globalWallet, addr, out privKey);
        if (!res)
            return (res);
        string dummy_addr;
        pubKey = CryptoClass.PrivKey2PubKeyAndAddr(privKey, out dummy_addr);
        return (res);
    }
    protected bool verifyTransSignature(Org.BouncyCastle.Math.BigInteger[] tranSignature)
    {
        var tran = new
        {
            from = lbSenderAddrValue.Text,
            to = tbRecipientAddrValue.Text,
            senderPubKey = WalletClass.FaucetPubKey,
            value = Convert.ToInt32(tbValue.Text),
            fee = 0,
            data = tbDataValue.Text,
            dateCreated = lbDateCreatedValue.Text,
        };
        string tranJson = JsonConvert.SerializeObject(tran);
        byte[] tranHash = CryptoClass.CalcSHA256(tranJson);
        ECPublicKeyParameters ecPubKey = CryptoClass.ToPublicKey(WalletClass.FaucetPrvKey);
        bool isVerified = CryptoClass.VerifySignature(ecPubKey, tranSignature, tranHash);
        lbFailSignature.Visible = !isVerified;
        return (isVerified);
    }
    protected bool doTransSignature(out Org.BouncyCastle.Math.BigInteger[] tranSignature)
    {
        tranSignature = CryptoClass.signTrans(WalletClass.FaucetPrvKey, WalletClass.FaucetAccount, tbRecipientAddrValue.Text, WalletClass.FaucetPubKey, Convert.ToInt32(tbValue.Text), 0, tbDataValue.Text, lbDateCreatedValue.Text);
        lbSignatureValue.Text = "[" + tranSignature[0].ToString(16) + ", " + tranSignature[1].ToString(16) + "]";
        return (verifyTransSignature(tranSignature));
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        if (!validateRecAddr() || !validateTransValue())
            return;
        // bool deriveRecipientPrivKey(string addr, out string privKey, out string pubKey)
        string privKey, pubKey;
        // protected bool deriveRecipientPrivKey(string addr, out string privKey, out string pubKey)
        if (!deriveRecipientPrivKey(tbRecipientAddrValue.Text, out privKey, out pubKey))
        {
            lbRecipientAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbRecipientAddrValue);
            return;
        }
        lbSenderAddrValue.Text = WalletClass.FaucetAccount;
        lbDateCreatedValue.Text = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fff") + "000Z";
        Org.BouncyCastle.Math.BigInteger[] tranSignature;
        if (!doTransSignature(out tranSignature))
            return;
        submit_signed_trans(tranSignature);
        setTransEnabled(false);
    }
    protected void submit_signed_trans(Org.BouncyCastle.Math.BigInteger[] tranSignature)
    {
        string Url = "http://" + tbxIPAddr.Text + ":" + tbPort.Text + "/transactions/send";
        var tranSigned = new
        {
            from = lbSenderAddrValue.Text,
            to = tbRecipientAddrValue.Text,
            senderPubKey = WalletClass.FaucetPubKey,
            value = Convert.ToInt32(tbValue.Text),
            fee = 0,
            data = tbDataValue.Text,
            dateCreated = lbDateCreatedValue.Text,
            senderSignature = new[]
            {
                tranSignature[0].ToString(16),
                tranSignature[1].ToString(16)
            }
        };
        string signedTranJson = JsonConvert.SerializeObject(tranSigned, Formatting.Indented);
        string response = "";
        string status_code = "";
        string message;
        lbReturnMessage.Visible = true;
        try
        {
            if (MyWebRequest.PostData(Url, signedTranJson, out response, out status_code))
            {
                var data2 = (JObject)JsonConvert.DeserializeObject(response);
                if (status_code == "OK")
                {
                    message = data2["transactionDataHash"].Value<string>();
                    lbReturnMessage.ForeColor = System.Drawing.Color.Green;
                    lbReturnMessage.Text = "Transaction {" + message + "} has been added into the pending transaction pool.";
                }
                else
                {
                    message = data2["errorMsg"].Value<string>();
                    lbReturnMessage.ForeColor = System.Drawing.Color.Red;
                    lbReturnMessage.Text = message;
                }
            }
            else
            {
                lbReturnMessage.Visible = true;
                lbReturnMessage.ForeColor = System.Drawing.Color.Red;
                if (response.Contains("400"))
                    lbReturnMessage.Text = "Invalid transaction: some field(s) are missing!";
                else if (response.Contains("401"))
                    lbReturnMessage.Text = "Invalid transaction: fund is not enough!";
                else if (response.Contains("402"))
                    lbReturnMessage.Text = "Duplicate transaction!";
                else if (response.Contains("405"))
                    lbReturnMessage.Text = "Duplicate Faucet transaction within 1 hour!";
            }
        }
        catch (WebException wbex)
        {
            lbReturnMessage.Visible = true;
            lbReturnMessage.ForeColor = System.Drawing.Color.Red;
            lbReturnMessage.Text = wbex.ToString();
        }
    }
    protected void tbxIPAddr_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbPort_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbPrivateKeyValue_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbRecipientAddrValue_TextChanged(object sender, EventArgs e)
    {

    }
}