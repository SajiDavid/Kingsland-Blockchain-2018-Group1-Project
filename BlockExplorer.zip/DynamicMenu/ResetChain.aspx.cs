﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;

public partial class ResetChain : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void tbxIPAddr_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbPort_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }
    protected bool ValidateIPAddr()
    {
        tbxIPAddr.Text = tbxIPAddr.Text.Trim();
        if (tbxIPAddr.Text.Length == 0)
        {
            lbIPAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbxIPAddr);
            return (false);
        }
        else
        {
            lbIPAddrTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
    }
    protected bool ValidatePort()
    {
        bool bPortValid;
        int iPort;
        tbPort.Text = tbPort.Text.Trim();
        bPortValid = int.TryParse(tbPort.Text, out iPort);
        if (bPortValid)
        {
            lbPort.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbPort.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPort);
            return (false);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!ValidateIPAddr() || !ValidatePort())
            return;
        string Url;
        MyWebRequest myRequest;
        String response = "";

        Url = "http://" + tbxIPAddr.Text + ":" + tbPort.Text + "/debug/reset-chain";
        //create the constructor with post type and few data
        myRequest = new MyWebRequest(Url, "GET");
        //show the response string on the console screen.
        try
        {
            response = myRequest.GetResponse();
            tbxResetMsg.ForeColor = new System.Drawing.Color();
            tbxResetMsg.Text = response;
        }
        catch (WebException we)
        {
            tbxResetMsg.ForeColor = System.Drawing.Color.Red;
            tbxResetMsg.Text = we.Message;
        }
    }

    protected void tbxBlockContent_TextChanged(object sender, EventArgs e)
    {

    }
}