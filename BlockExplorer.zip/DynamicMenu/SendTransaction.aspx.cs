﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Org.BouncyCastle.Math.EC;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Asn1.X9;
using Org.BouncyCastle.Asn1.Sec;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Signers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;


public partial class SendTransaction : System.Web.UI.Page
{
    bool firstRun;
    protected void Page_Load(object sender, EventArgs e)
    {
        firstRun = true;
        if( WalletClass.globalWallet!=null )
        {
            lbWalletUnloaded.Text = "Wallet Loaded";
            lbWalletUnloaded.ForeColor = System.Drawing.Color.Green;
            tbxIPAddr.Enabled = true;
            tbPort.Enabled = true;
            btnSendTransaction.Enabled = true;
        }
        else
        {
            lbWalletUnloaded.Text = "Wallet NOT Loaded";
            lbWalletUnloaded.ForeColor = System.Drawing.Color.Red;
            tbxIPAddr.Enabled = false;
            tbPort.Enabled = false;
            btnSendTransaction.Enabled = false;
        }
    }

    protected void tbxIPAddr_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbPort_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbxTransHash_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }
    protected bool ValidateIPAddr()
    {
        tbxIPAddr.Text = tbxIPAddr.Text.Trim();
        if (tbxIPAddr.Text.Length == 0)
        {
            lbIPAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbxIPAddr);
            return (false);
        }
        else
        {
            lbIPAddrTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
    }
    protected bool ValidatePort()
    {
        bool bPortValid;
        int iPort;
        tbPort.Text = tbPort.Text.Trim();
        bPortValid = int.TryParse(tbPort.Text, out iPort);
        if (bPortValid)
        {
            lbPort.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbPort.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPort);
            return (false);
        }
    }
    protected void setTransVisible(bool visible)
    {
        lbTransInfo.Visible = visible;
        lbPrivateKeyTitle.Visible = visible;
        tbPrivateKeyValue.Visible = visible;
        lbPubKeyTitle.Visible = visible;
        lbPubKeyValue.Visible = visible;
        lbSenderAddrTitle.Visible = visible;
        lbSenderAddrValue.Visible = visible;
        lbRecipientAddrTitle.Visible = visible;
        tbRecipientAddrValue.Visible = visible;
        lbValueTitle.Visible = visible;
        tbValue.Visible = visible;
        lbFeeTitle.Visible = visible;
        tbFeeValue.Visible = visible;
        lbDataTitle.Visible = visible;
        tbDataValue.Visible = visible;
        lbDateCreatedTitle.Visible = visible;
        lbDateCreatedValue.Visible = visible;
        lbSignatureTitle.Visible = visible;
        lbSignatureValue.Visible = visible;
        btnSubmit.Visible = visible;
        cbFaucetTrans.Visible = visible;
    }
    protected void setTransEnabled(bool enabled)
    {
        tbPrivateKeyValue.Enabled = enabled;
        tbRecipientAddrValue.Enabled = enabled;
        tbValue.Enabled = enabled;
        tbFeeValue.Enabled = enabled;
        tbDataValue.Enabled = enabled;
        btnSubmit.Enabled = enabled;
        cbFaucetTrans.Enabled = enabled;
        if( enabled )
        {
            tbPrivateKeyValue.Text = "";
            lbPubKeyValue.Text = "";
            lbSenderAddrValue.Text = "";
            tbRecipientAddrValue.Text = "";
            tbValue.Text = "";
            tbFeeValue.Text = "";
            tbDataValue.Text = "";
            lbDateCreatedValue.Text = "";
            lbSignatureValue.Text = "";
            lbReturnMessage.Text = "";
            cbFaucetTrans.Checked = false;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!ValidateIPAddr() || !ValidatePort())
            return;
        if( firstRun )
        {
            firstRun = false;
            setTransVisible(true);
        }
        setTransEnabled(true);
    }
    protected void processFaucetTrans()
    {
        if( cbFaucetTrans.Checked )
        {
            tbFeeValue.Text = "0";
            tbFeeValue.Enabled = false;
        }
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        if (!validatePrivKey() || !validateRecAddr() || !validateTransValue() || !validateTransFee())
            return;
        processFaucetTrans();
        string senderAddr1, senderAddr2;
        bool res = WalletClass.getAddrFromWallet(WalletClass.globalWallet, tbPrivateKeyValue.Text, out senderAddr1);
        lbPubKeyValue.Text = CryptoClass.PrivKey2PubKeyAndAddr(tbPrivateKeyValue.Text, out senderAddr2);
        if ( res )
            lbSenderAddrValue.Text = senderAddr1;
        else
            lbSenderAddrValue.Text = senderAddr2;
        lbDateCreatedValue.Text = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fff") + "000Z";
        Org.BouncyCastle.Math.BigInteger[] tranSignature = CryptoClass.signTrans(tbPrivateKeyValue.Text, lbSenderAddrValue.Text, tbRecipientAddrValue.Text, lbPubKeyValue.Text, Convert.ToInt32(tbValue.Text), Convert.ToInt32(tbFeeValue.Text), tbDataValue.Text, lbDateCreatedValue.Text);
        lbSignatureValue.Text = "[" + tranSignature[0].ToString(16) + ", " + tranSignature[1].ToString(16) + "]";
        if (!verifyTransSignature(tranSignature))
            return;
        submit_signed_trans( tranSignature );
        setTransEnabled(false);
    }
    protected bool verifyTransSignature(Org.BouncyCastle.Math.BigInteger[] tranSignature)
    {
        var tran = new
        {
            from = lbSenderAddrValue.Text,
            to = tbRecipientAddrValue.Text,
            senderPubKey = lbPubKeyValue.Text,
            value = Convert.ToInt32(tbValue.Text),
            fee = Convert.ToInt32(tbFeeValue.Text),
            data = tbDataValue.Text,
            dateCreated = lbDateCreatedValue.Text,
        };
        string tranJson = JsonConvert.SerializeObject(tran);
        byte[] tranHash = CryptoClass.CalcSHA256(tranJson);
        ECPublicKeyParameters ecPubKey = CryptoClass.ToPublicKey(tbPrivateKeyValue.Text);
        bool isVerified = CryptoClass.VerifySignature(ecPubKey, tranSignature, tranHash);
        lbFailSignature.Visible = !isVerified;
        return (isVerified);
    }
    protected void submit_signed_trans(Org.BouncyCastle.Math.BigInteger[] tranSignature)
    {
        string Url = "http://" + tbxIPAddr.Text + ":" + tbPort.Text + "/transactions/send";
        var tranSigned = new
        {
            from = lbSenderAddrValue.Text,
            to = tbRecipientAddrValue.Text,
            senderPubKey = lbPubKeyValue.Text,
            value = Convert.ToInt32(tbValue.Text),
            fee = Convert.ToInt32(tbFeeValue.Text),
            data = tbDataValue.Text,
            dateCreated = lbDateCreatedValue.Text,
            senderSignature = new[]
            {
                tranSignature[0].ToString(16),
                tranSignature[1].ToString(16)
            }
        };
        string signedTranJson = JsonConvert.SerializeObject(tranSigned, Formatting.Indented);
        string response = "";
        string status_code = "";
        string message;
        lbReturnMessage.Visible = true;
        try
        {
            if (MyWebRequest.PostData(Url, signedTranJson, out response, out status_code))
            {
                var data2 = (JObject)JsonConvert.DeserializeObject(response);
                if (status_code == "OK")
                {
                    message = data2["transactionDataHash"].Value<string>();
                    lbReturnMessage.ForeColor = System.Drawing.Color.Green;
                    lbReturnMessage.Text = "Transaction {" + message + "} has been added into the pending transaction pool.";
                }
                else
                {
                    message = data2["errorMsg"].Value<string>();
                    lbReturnMessage.ForeColor = System.Drawing.Color.Red;
                    lbReturnMessage.Text = message;
                }
            }
            else
            {
                lbReturnMessage.Visible = true;
                lbReturnMessage.ForeColor = System.Drawing.Color.Red;
                if( response.Contains("400"))
                    lbReturnMessage.Text = "Invalid transaction: some field(s) are missing!";
                else if( response.Contains("401"))
                    lbReturnMessage.Text = "Invalid transaction: fund is not enough!";
                else if( response.Contains("402"))
                    lbReturnMessage.Text = "Duplicate transaction!";
            }
        }
        catch (WebException wbex)
        {
            lbReturnMessage.Visible = true;
            lbReturnMessage.ForeColor = System.Drawing.Color.Red;
            lbReturnMessage.Text = wbex.ToString();
        }
    }
    protected void tbPrivateKeyValue_TextChanged(object sender, EventArgs e)
    {
    }
    protected bool validatePrivKey()
    {
        bool valid = true;
        tbPrivateKeyValue.Text = tbPrivateKeyValue.Text.Trim();
        string privKey = tbPrivateKeyValue.Text;
        if (privKey.Length != 64)
            valid = false;
        for (int c = 0; c < privKey.Length; c++)
        {
            if ((privKey[c] >= '0' && privKey[c] <= '9') || (privKey[c] >= 'a' && privKey[c] <= 'f'))
                continue;
            else
                valid = false;
        }
        if( !valid )
        {
            lbPrivateKeyTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPrivateKeyValue);
        }
        else
        {
            lbPrivateKeyTitle.ForeColor = new System.Drawing.Color();
        }
        return (valid);
    }
    protected bool validateRecAddr()
    {
        bool valid = true;
        tbRecipientAddrValue.Text = tbRecipientAddrValue.Text.Trim();
        string RecAddr = tbRecipientAddrValue.Text;
        if (RecAddr.Length != 40)
            valid = false;
        for (int c = 0; c < RecAddr.Length; c++)
        {
            if ((RecAddr[c] >= '0' && RecAddr[c] <= '9') || (RecAddr[c] >= 'a' && RecAddr[c] <= 'f') || (RecAddr[c] >= 'A' && RecAddr[c] <= 'F'))
                continue;
            else
                valid = false;
        }
        if (!valid)
        {
            lbRecipientAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbRecipientAddrValue);
        }
        else
        {
            lbRecipientAddrTitle.ForeColor = new System.Drawing.Color();
        }
        return (valid);
    }
    protected bool validateTransValue()
    {
        int iValue;
        bool bValidValue;
        bValidValue = int.TryParse(tbValue.Text, out iValue);
        if (bValidValue && iValue>0)
        {
            lbValueTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbValueTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbValue);
            return (false);
        }
    }
    protected bool validateTransFee()
    {
        int iFee;
        bool bValidFee;
        bValidFee = int.TryParse(tbFeeValue.Text, out iFee);
        if (cbFaucetTrans.Checked)  // In a Faucet transaction, the fee must be 0
        {
            if (bValidFee && iFee == 0)
            {
                lbFeeTitle.ForeColor = new System.Drawing.Color();
                return (true);
            }
            else
            {
                lbFeeTitle.ForeColor = System.Drawing.Color.Red;
                this.Page.SetFocus(tbFeeValue);
                return (false);
            }
        }
        else
        {
            if (bValidFee && iFee >= 10)
            {
                lbFeeTitle.ForeColor = new System.Drawing.Color();
                return (true);
            }
            else
            {
                lbFeeTitle.ForeColor = System.Drawing.Color.Red;
                this.Page.SetFocus(tbFeeValue);
                return (false);
            }
        }
    }

    protected void cbFaucetTrans_CheckedChanged(object sender, EventArgs e)
    {
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}