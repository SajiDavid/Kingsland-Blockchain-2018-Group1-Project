﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using Nethereum.HdWallet;
using Nethereum.Web3;
using Nethereum.Web3.Accounts;
using Newtonsoft.Json;
using NBitcoin;
using Rijndael256;

public partial class LoadWallet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnReturn_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }
    protected bool validatePassword()
    {
        bool res = (tbPassword.Text.Length>0);
        if( res )
        {
            lbPassword.ForeColor = new System.Drawing.Color();
        }
        else
        {
            lbPassword.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPassword);
        }
        return (res);
    }
    protected bool validateWalletFile()
    {
        tbWalletFile.Text = tbWalletFile.Text.Trim();
        bool res = File.Exists(tbWalletFile.Text);
        if (res)
        {
            lbWalletFile.ForeColor = new System.Drawing.Color();
        }
        else
        {
            lbWalletFile.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbWalletFile);
        }
        return (res);
    }
    protected void btnLoad_Click(object sender, EventArgs e)
    {
        if (!validatePassword() || !validateWalletFile())
            return;
        try
        {
            WalletClass.globalWallet = WalletClass.LoadWalletFromJsonFile(tbWalletFile.Text, tbPassword.Text);
            WalletClass.showAddresses(WalletClass.globalWallet, tbAddresses);
            WalletClass.showPrivKeys(WalletClass.globalWallet, tbPrivKeys);
            bool bl = WalletClass.isAddrInWallet(WalletClass.globalWallet, "42d25eAEF4Bd7C6D4c183991194EDA1e328f63B1");
        }
        catch (Exception ex)
        {
            tbAddresses.ForeColor = System.Drawing.Color.Red;
            tbAddresses.Text = ex.ToString();
        }
    }
}