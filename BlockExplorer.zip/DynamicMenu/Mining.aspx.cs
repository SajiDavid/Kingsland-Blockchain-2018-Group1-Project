﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Threading;

public partial class Mining : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        initPage(WalletClass.globalWallet != null);
    }
    protected void initPage(bool visible)
    {
        if( visible )
        {
            lbWalletUnloaded.Text = "Wallet Loaded";
            lbWalletUnloaded.ForeColor = System.Drawing.Color.Green;
        }
        else
        {
            lbWalletUnloaded.Text = "Wallet NOT Loaded";
            lbWalletUnloaded.ForeColor = System.Drawing.Color.Red;
        }
        tbxIPAddr.Enabled = visible;
        tbPort.Enabled = visible;
        btnMining.Enabled = visible;
        lbPrivateKeyTitle.Visible = visible;
        tbPrivKey.Visible = visible;
        lbRewardAddrTitle.Visible = visible;
        lbRewardAddrValue.Visible = visible;
    }
    protected bool ValidateIPAddr()
    {
        tbxIPAddr.Text = tbxIPAddr.Text.Trim();
        if (tbxIPAddr.Text.Length == 0)
        {
            lbIPAddrTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbxIPAddr);
            return (false);
        }
        else
        {
            lbIPAddrTitle.ForeColor = new System.Drawing.Color();
            return (true);
        }
    }
    protected bool ValidatePort()
    {
        bool bPortValid;
        int iPort;
        tbPort.Text = tbPort.Text.Trim();
        bPortValid = int.TryParse(tbPort.Text, out iPort);
        if (bPortValid)
        {
            lbPort.ForeColor = new System.Drawing.Color();
            return (true);
        }
        else
        {
            lbPort.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPort);
            return (false);
        }
    }
    protected void getMiningJob()
    {
        string Url;
        MyWebRequest myRequest;
        string response = "";
        Url = "http://" + tbxIPAddr.Text + ":" + tbPort.Text + "/mining/get-mining-job/" + lbRewardAddrValue.Text;
        //create the constructor with post type and few data
        myRequest = new MyWebRequest(Url, "GET");
        //show the response string on the console screen.
        try
        {
            response = myRequest.GetResponse();
            CryptoClass.BlockDataHash = process_response(response);
            WalletClass.getMiningJob_succ = true;
        }
        catch (WebException we)
        {
            handle_error(we);
            WalletClass.getMiningJob_succ = false;
        }
    }
    protected bool retrieveRewardingAddress()
    {
        bool valid = true;
        tbPrivKey.Text = tbPrivKey.Text.Trim();
        string privKey = tbPrivKey.Text;
        if (privKey.Length != 64)
            valid = false;
        for (int c = 0; c < privKey.Length; c++)
        {
            if ((privKey[c] >= '0' && privKey[c] <= '9') || (privKey[c] >= 'a' && privKey[c] <= 'f'))
                continue;
            else
                valid = false;
        }
        if (!valid)
        {
            lbPrivateKeyTitle.ForeColor = System.Drawing.Color.Red;
            this.Page.SetFocus(tbPrivKey);
            return(valid);
        }
        lbPrivateKeyTitle.ForeColor = new System.Drawing.Color();
        string rewardAddr1, rewardAddr2;
        bool bl = WalletClass.getAddrFromWallet(WalletClass.globalWallet, tbPrivKey.Text, out rewardAddr1);
        if (bl)
            lbRewardAddrValue.Text = rewardAddr1;
        else
        {
            string pubkey = CryptoClass.PrivKey2PubKeyAndAddr(tbPrivKey.Text, out rewardAddr2);
            lbRewardAddrValue.Text = rewardAddr2;
        }
        return (valid);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!ValidateIPAddr() || !ValidatePort())
            return;
        if (!retrieveRewardingAddress())
            return;
        initiateForm();
        getMiningJob();
        if (WalletClass.getMiningJob_succ)
        {
            lbFailToConnect.Visible = false;
            doMining();
        }
        else
        {
            lbFailToConnect.Visible = true;
        }
    }
    protected void handle_error(WebException we)
    {
        lbMiningError.Visible = true;
        lbIndexTitle.Visible = false;
        lbIndexValue.Visible = false;
        lbTransNumTitle.Visible = false;
        lbTransNumValue.Visible = false;
        lbDifficultyTitle.Visible = false;
        lbDifficultyValue.Visible = false;
        lbExpectedRewardTitle.Visible = false;
        lbExpectedRewardValue.Visible = false;
        lbBlockDataHashTitle.Visible = false;
        lbBlockDataHashValue.Visible = false;
    }
    protected string process_response(string response)
    {
        lbMiningError.Visible = false;
        lbIndexTitle.Visible = true;
        lbIndexValue.Visible = true;
        var data = (JObject)JsonConvert.DeserializeObject(response);
        string sIndex = data["index"].Value<string>();
        lbIndexValue.Text = sIndex;
        lbTransNumTitle.Visible = true;
        lbTransNumValue.Visible = true;
        string sTransNum = data["transactionsIncluded"].Value<string>();
        lbTransNumValue.Text = sTransNum;
        lbDifficultyTitle.Visible = true;
        lbDifficultyValue.Visible = true;
        string sDifficulty = data["difficulty"].Value<string>();
        lbDifficultyValue.Text = sDifficulty;
        lbExpectedRewardTitle.Visible = true;
        lbExpectedRewardValue.Visible = true;
        string sExpectedReward = data["expectedReward"].Value<string>();
        lbExpectedRewardValue.Text = sExpectedReward;
        lbRewardAddrTitle.Visible = true;
        lbRewardAddrValue.Visible = true;
        string sRewardAddr = data["rewardAddress"].Value<string>();
        lbRewardAddrValue.Text = sRewardAddr;
        lbBlockDataHashTitle.Visible = true;
        lbBlockDataHashValue.Visible = true;
        string sBlockDataHash = data["blockDataHash"].Value<string>();
        lbBlockDataHashValue.Text = sBlockDataHash;
        return (sBlockDataHash);
    }
    protected void refreshMiningInfo(int nonce, string datetime_str, string data_hash)
    {
        lbStartMining.Visible = true;
        lbNonceTitle.Visible = true;
        lbNonceValue.Visible = true;
        lbNonceValue.Text = nonce.ToString();
        lbDateCreatedTitle.Visible = true;
        lbDateCreatedValue.Visible = true;
        lbDateCreatedValue.Text = datetime_str;
        lbBlockHashTitle.Visible = true;
        lbDataHashValue.Visible = true;
        lbDataHashValue.Text = data_hash;
    }
    protected void doMining()
    {
        int iNonce = 0;
        string sNow = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
        string data_hash = CryptoClass.ComputeSha256Hash(CryptoClass.BlockDataHash + sNow + iNonce.ToString());
        int difficulty = Convert.ToInt32(lbDifficultyValue.Text);
        string startingZeros = new String('0', difficulty);
        refreshMiningInfo(iNonce, sNow, data_hash);

        while(data_hash.Substring(0, difficulty)!=startingZeros)
        {
            iNonce++;
            sNow = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
            data_hash = CryptoClass.ComputeSha256Hash(CryptoClass.BlockDataHash + sNow + iNonce.ToString());
            if( (iNonce % 10000 == 0) && (data_hash.Substring(0, difficulty) != startingZeros) )
            {
                Thread t = new Thread(getMiningJob);
                t.Start();
                refreshMiningInfo(iNonce, sNow, data_hash);
            }
        }
        lbHitMsg.Visible = true;
        refreshMiningInfo(iNonce, sNow, data_hash);
        submit_mined_block(iNonce, sNow, data_hash);
    }
    protected void submit_mined_block( int iNonce, string sNow, string data_hash )
    {
        lbSubmitBlock.Visible = true;
        string Url = "http://" + tbxIPAddr.Text + ":" + tbPort.Text + "/mining/submit-mined-block";
        string data = "{ \"blockDataHash\": \"" + CryptoClass.BlockDataHash + "\", \"dateCreated\": \"" 
            + sNow + "\", \"nonce\": " + iNonce.ToString() + ", \"blockHash\": \"" + data_hash
            + "\"}";
        string response = "";
        string status_code = "";
        string message;
        try
        {
            if (MyWebRequest.PostData(Url, data, out response, out status_code))
            {
                lbReturnMessage.Visible = true;
                var data2 = (JObject)JsonConvert.DeserializeObject(response);
                if (status_code == "OK")
                {
                    message = data2["message"].Value<string>();
                    lbReturnMessage.ForeColor = System.Drawing.Color.Green;
                    lbReturnMessage.Text = message;
                }
                else
                {
                    message = data2["errorMsg"].Value<string>();
                    lbReturnMessage.ForeColor = System.Drawing.Color.Red;
                    lbReturnMessage.Text = message;
                }
            }
            else
            {
                lbReturnMessage.Visible = true;
                lbReturnMessage.ForeColor = System.Drawing.Color.Red;
                lbReturnMessage.Text = response;
            }
        } catch( WebException wbex )
        {
            lbReturnMessage.Visible = true;
            lbReturnMessage.ForeColor = System.Drawing.Color.Red;
            lbReturnMessage.Text = wbex.ToString();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/BlockExplorer.aspx");
    }

    protected void tbxIPAddr_TextChanged(object sender, EventArgs e)
    {

    }

    protected void tbPort_TextChanged(object sender, EventArgs e)
    {

    }
    protected void initiateForm()
    {
        lbGetMiningJob.Visible = false;
        lbMiningError.Visible = false;
        lbIndexTitle.Visible = false;
        lbIndexValue.Visible = false;
        lbTransNumTitle.Visible = false;
        lbTransNumValue.Visible = false;
        lbDifficultyTitle.Visible = false;
        lbDifficultyValue.Visible = false;
        lbExpectedRewardTitle.Visible = false;
        lbExpectedRewardValue.Visible = false;
        lbBlockDataHashTitle.Visible = false;
        lbBlockDataHashValue.Visible = false;
        lbStartMining.Visible = false;
        lbHitMsg.Visible = false;
        lbNonceTitle.Visible = false;
        lbNonceValue.Visible = false;
        lbDateCreatedTitle.Visible = false;
        lbDateCreatedValue.Visible = false;
        lbBlockHashTitle.Visible = false;
        lbDataHashValue.Visible = false;
        lbSubmitBlock.Visible = false;
        lbReturnMessage.Visible = false;
    }
}